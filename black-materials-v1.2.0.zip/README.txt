Species label materials / 物种标签材料 — v1.2.0 (black)

This package contains 22 standalone SVG illustrations and 22 complete SVG label plates, with source and version manifests.
本包包含22张独立SVG剪影、22张完整SVG标签，以及来源和版本说明。

Website / 网站: https://wwei55166-jpg.github.io/ecological-tank-species-labels/black.html

The self-contained offline website is saved separately in the local project folder.
离线网页单独保存在本地项目文件夹中。
See CREDITS.md and MATERIALS_MANIFEST.json for scientific scopes and source reuse conditions.
